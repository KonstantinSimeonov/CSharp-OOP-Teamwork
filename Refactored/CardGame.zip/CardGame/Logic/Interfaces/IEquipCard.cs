﻿namespace Logic.Interfaces
{
     public interface IEquipCard
    {
        IMonsterCard Target { get; }
    }
}
