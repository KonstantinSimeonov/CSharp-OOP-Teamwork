﻿
namespace Logic.Interfaces
{
   public interface IHumanPlayer : IPlayer
    {
        // TODO: Discuss the mandatory methods the Human player should implement independently
    }
}
