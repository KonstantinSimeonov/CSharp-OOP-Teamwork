﻿
namespace Logic.Interfaces
{
  public interface IArtificialIntelligence : IPlayer
    {
        // TODO: Discuss the mandatory methods that the AI should implement independently
    }
}
