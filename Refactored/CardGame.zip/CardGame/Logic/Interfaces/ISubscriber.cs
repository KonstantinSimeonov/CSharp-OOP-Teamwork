﻿namespace Logic.Interfaces
{
   public interface IFormSubscriber
    {
       void Subscribe(IFormPublisher publisher);
    }
}
