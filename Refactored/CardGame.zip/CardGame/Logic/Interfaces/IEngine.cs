﻿
namespace Logic.Interfaces
{
    public interface IEngine // one of the last things to implement
    {
        void Run();
    }
}
