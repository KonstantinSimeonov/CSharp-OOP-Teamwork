﻿namespace Logic.Interfaces
{
   public interface ISpecialCard // special cards will have an effect
    {
        void ApplyEffect();
    }
}
