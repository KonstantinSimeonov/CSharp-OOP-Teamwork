﻿namespace Logic.Cards
{
    public enum CardTypes
    {
        Spell,
        Equip,
        Field,
        Trap,
        Monster,
        SpecialMonster
    }
}
