﻿namespace Logic.Menu
{
    using Logic.Interfaces;

    public class Menu : IMenu // I feel like that class will not be necessary, considering the nature of the windows forms
    {
        public void Display()
        {
            throw new System.NotImplementedException();
        }

        public void ChooseOption(int optionNumber)
        {
            throw new System.NotImplementedException();
        }
    }
}