﻿namespace Game
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.Data;
    using System.Drawing;
    using System.Linq;
    using System.Text;
    using System.Threading;
    using System.Threading.Tasks;
    using System.Windows.Forms;
    using Logic.CustomEventArgs;
    using Logic.Interfaces;
    using Logic.Delegates;
    using Logic.Cards;

    public partial class CardGame : Form, IFormPublisher
    {
        private bool firstDraw;

        private PictureBox[] pHandC;
        private PictureBox[] pSpellC;
        private PictureBox[] pFieldC;
        private PictureBox[] aiMonsters;
        private PictureBox[] aiSpells;

        private readonly Image facedown = Image.FromFile(@"..\..\Resources\DeckImgCurrent\face_down_monster_card.jpg");

        public CardGame()
        {
            InitializeComponent();
            pHandC = new PictureBox[] { PCard1, PCard2, PCard3, PCard4, PCard5, PCard6, PCard7, PCard8 };
            pSpellC = new PictureBox[] { PlayerSpell1, PlayerSpell2, PlayerSpell3, PlayerSpell4, PlayerSpell5 };
            pFieldC = new PictureBox[] { PlayerMonster1, PlayerMonster2c, PlayerMonster3, PlayerMonster4, PlayerMonster5 };
            aiMonsters = new PictureBox[] { CompMonster1, CompMonster2, CompMonster3, CompMonster4, CompMonster5 };
            aiSpells = new PictureBox[] { CompSpell1, CompSpell2, CompSpell3, CompSpell4, CompSpell5 };
            this.firstDraw = true;
        }

        private PictureBox GetFirstEmpty(PictureBox[] boxes)
        {
            return boxes.Where(x => x.Image == null).First();
        }

        private void SetZoom(object sender, EventArgs e)
        {
            var box = sender as PictureBox;

            if (box.Image == null)
                return;

            int index = int.Parse(box.Image.Tag.ToString());
            this.ZoomMonsterCard.ImageLocation = string.Format(@"../../Resources/DeckImgCurrent/BigCards/{0}.jpg", index);
        }

        #region WTF
        private void CardGame_Load(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox6_Click(object sender, EventArgs e)
        {

        }


        private void pictureBox6_MouseEnter(object sender, EventArgs e)
        {

        }

        private void pictureBox11_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox11_MouseUp(object sender, MouseEventArgs e)
        {

        }

        private void pictureBox10_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox6_MouseLeave(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click_1(object sender, EventArgs e)
        {

        }

        private void pictureBox13_Click(object sender, EventArgs e)
        {

        }

        private void CompMonster3_Click(object sender, EventArgs e)
        {

        }

        private void PlayerSpell3_Click(object sender, EventArgs e)
        {

        }

        private void PlayerMonster5_Click(object sender, EventArgs e)
        {

        }

        private void PlayerMonster5_MouseHover(object sender, EventArgs e)
        {

        }



        private void PCard2_Click(object sender, EventArgs e)
        {

        }

        private void PCard5_Click(object sender, EventArgs e)
        {

        }

        private void PCard1_Click(object sender, EventArgs e)
        {

        }

        private void PCard8_Click(object sender, EventArgs e)
        {

        }

        private void PCard6_Click(object sender, EventArgs e)
        {


        }

        private void CompMonster4_Click(object sender, EventArgs e)
        {

        }

        private void PlayerMonster1_Click(object sender, EventArgs e)
        {

        }

        private void PCard2_MouseDoubleClick(object sender, MouseEventArgs e)
        {

        }

        #endregion

        #region WTF
        private void PDeck_MouseDoubleClick(object sender, MouseEventArgs e)
        {

        }

        private void PDeck_Click(object sender, EventArgs e)
        {

        }

        private void PlayerSpell1_Click(object sender, EventArgs e)
        {

        }

        private void PCard8_Click_1(object sender, EventArgs e)
        {

        }

        private void PlayerSpell5_Click(object sender, EventArgs e)
        {

        }

        #endregion

        /// <summary>
        /// Raises an event to which the board subscribes.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void DrawButton_Click(object sender, EventArgs e)
        {
            var args = new BoardReportArgs(true, true, true);
            this.DrawEvent(sender, args);
            this.UpdateUI(args);
            this.DrawButton.Enabled = false;
        }

        private void UpdateUI(BoardReportArgs args)
        {
            for (int i = 0; i < pFieldC.Length; i++)
            {
                if (args.PlayerMonsters.Count > i)
                    UpdateBox(this.pFieldC[i], args.PlayerMonsters[i], args.PlayerMonsters[i].FaceUp);
                if (args.PlayerEffects.Count > i)
                    UpdateBox(this.pSpellC[i], args.PlayerEffects[i], args.PlayerEffects[i].FaceUp);
                if (args.AIMonsters.Count > i)
                    UpdateBox(this.aiMonsters[i], args.AIMonsters[i], args.AIMonsters[i].FaceUp);
                if (args.AIEffects.Count > i)
                    UpdateBox(this.aiSpells[i], args.AIEffects[i], args.AIEffects[i].FaceUp);
                if (args.Player.Hand.Count > i)
                    UpdateBox(this.pHandC[i], args.Player.Hand[i]);
            }
        }

        private void UpdateBox(PictureBox box, ICard card, bool faceUp = true)
        {
            box.Image = faceUp ? card.CardImage : this.FaceDown();
            if(!faceUp)
            box.Image.Tag = card.CardImage.Tag;

        }

        private void button5_Click(object sender, EventArgs e)
        {
            this.DisablePlayerUI();
            var args = new BoardReportArgs(false, false, true);
            this.End(sender, args);
            this.UpdateUI(args);
        }

        private void PlayerMonster2c_Click(object sender, EventArgs e)
        {

        }

        #region Events
        // TODO: implement the remaining events

        public event EventRaiser DrawEvent;

        public event EventRaiser RequestStateReport;

        public event EventRaiser RequestCardsLeft;

        public event EventRaiser PlayCardEvent;

        public event EventRaiser Main1;

        public event EventRaiser Battle;

        public event EventRaiser Main2;

        public event EventRaiser End;

        public event EventRaiser GameOver;

        #endregion

        private PictureBox[] GetField(ICard card, bool playerTurn = true)
        {
            switch (card.Type)
            {
                case CardTypes.Spell:
                    return playerTurn ? this.pSpellC : this.aiSpells;
                case CardTypes.Equip:
                    return playerTurn ? this.pSpellC : this.aiSpells;
                case CardTypes.Field:
                    return playerTurn ? this.pSpellC : this.aiSpells;
                case CardTypes.Trap:
                    return playerTurn ? this.pSpellC : this.aiSpells;
                case CardTypes.Monster:
                    return playerTurn ? this.pFieldC : this.aiMonsters;
                case CardTypes.SpecialMonster:
                    return playerTurn ? this.pFieldC : this.aiMonsters;
                default:
                    throw new NotImplementedException("em kot takoa");
            }
        }

        private void PlayerCardsInDeck_Click(object sender, EventArgs e)
        {

        }

        private void DisablePlayerUI()
        {
            // TODO: make this method useful or delete it

            foreach (var box in this.pHandC)
            {
                box.Enabled = false;
            }

            this.Phase1Button.Enabled = this.Phase2Button.Enabled = this.BattleButton.Enabled = this.EndTurnButton.Enabled = false;

        }

        private void BattleButton_Click(object sender, EventArgs e)
        {
            this.Phase1Button.Enabled = false;
            // TODO: implement battle
            this.Battle(sender, e);
        }

        private void Phase1Button_Click(object sender, EventArgs e)
        {
            this.BattleButton.Enabled = true;
            // TODO: do it correctly
            this.Main1(sender, e);
        }

        private void Phase2Button_Click(object sender, EventArgs e)
        {
            this.BattleButton.Enabled = false;
            // TODO: do it correctly
            this.Main2(sender, e);
        }

        private void RaisePlay(object sender, MouseEventArgs e)
        {
            // TODO: add a message box that ask for monster position or something like that

            bool left = e.Button == MouseButtons.Left;

            var box = sender as PictureBox;
            var args = new BoardReportArgs(this.EndTurnButton.Enabled, this.EndTurnButton.Enabled, left, box.Image.Tag.ToString());
            this.PlayCardEvent(sender, args);
            this.UpdateUI(args);
            box.Image = null;
        }

        private void PCard1_Click_1(object sender, EventArgs e)
        {

        }

        private Image FaceDown()
        {
            return Image.FromFile(@"..\..\Resources\DeckImgCurrent\face_down_monster_card.jpg");
        }
    }
}
