﻿namespace Game
{
    using Engine;
    public class Program
    {
        static void Main()
        {
            Engine.Instance.Run();
        }
    }
}