﻿namespace Engine
{
    public enum Phases
    {
        Draw,
        Main1,
        Battle,
        Main2
    }
}
