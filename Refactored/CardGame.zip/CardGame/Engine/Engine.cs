﻿namespace Engine
{
    using Game;
    using Logic.Interfaces;
    using Logic.Board;
    using Logic.Factory;
    using Logic.Player;
    using System;
    using System.Threading.Tasks;
    using System.Windows.Forms;
    using Logic.CustomEventArgs;

    public class Engine : IEngine
    {
        private bool playersTurn;
        private Phases phase;

        private static readonly Engine gameEngine = new Engine();

        /// <summary>
        /// Returns the only instance of the engine class.
        /// </summary>
        public static Engine Instance
        {
            get { return gameEngine; }
        }

        private Engine()
        {
            this.playersTurn = true;
            this.phase = Phases.Draw;
        }

        [STAThread]
        public void Run()
        {
            // TODO: refactoring

            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            var fack = Factory.Instance;
            var form = new CardGame();
            var PlayerDeck = fack.AssembleDeck();
            Board board = Board.Instance;
            board.Subscribe(form);
            Application.Run(form);
        }

    }
}